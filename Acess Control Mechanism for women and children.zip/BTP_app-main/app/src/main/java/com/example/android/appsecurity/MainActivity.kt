package com.example.android.appsecurity

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.example.android.appsecurity.about.AboutActivity
import com.example.android.appsecurity.appanalysis.AppAnalysisActivity
import com.example.android.appsecurity.extras.logBTP
import com.example.android.appsecurity.monitoring.Actions
import com.example.android.appsecurity.monitoring.EndlessService
import com.example.android.appsecurity.monitoring.ServiceState
import com.example.android.appsecurity.monitoring.getServiceState
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        title = "App Security"

        btnStartMonitoring.setOnClickListener {
            logBTP("Start Monitoring button pressed")
            actionOnService(Actions.START)
        }

        btnStopMonitoring.setOnClickListener {
            logBTP("Start Monitoring button pressed")
            actionOnService(Actions.STOP)
        }

        btnAppAnalysis.setOnClickListener {
            logBTP("")
            Intent(this, AppAnalysisActivity::class.java).also {
                startActivity(it)
            }
        }

        btnAbout.setOnClickListener {
            Intent(this, AboutActivity::class.java).also {
                startActivity(it)
            }
        }
    }

    private fun actionOnService(action: Actions) {
        if (getServiceState(this) == ServiceState.STOPPED && action == Actions.STOP) return
        Intent(this, EndlessService::class.java).also {
            it.action = action.name
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Log.d("ForegroundService", "Starting service in >=26 mode")
                startForegroundService(it)
            } else {
                Log.d("ForegroundService", "Starting service in <26 mode")
                startService(it)
            }
        }
    }
}