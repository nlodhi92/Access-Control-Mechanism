package com.example.android.appsecurity.appanalysis

import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.android.appsecurity.R
import com.example.android.appsecurity.extras.Utilities
import com.example.android.appsecurity.extras.logBTP
import com.example.android.appsecurity.models.AppItem
import com.google.android.material.snackbar.Snackbar
import com.google.common.hash.BloomFilter
import com.google.common.hash.Funnels
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.find
import org.jetbrains.anko.uiThread
import org.json.JSONObject
import java.io.IOException
import java.nio.charset.Charset
import java.util.*


class AppAnalysisActivity : AppCompatActivity(), AppAdapter.OnContextItemClickListener {

    private lateinit var progressBar: ProgressBar
    private val appList = ArrayList<AppItem>()
    private lateinit var contextItemPackageName: String

    private lateinit var mAdapter: AppAdapter
    private lateinit var mLinearLayoutManager: LinearLayoutManager
    lateinit var mRecyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_app_analysis)

        title = "App Analysis"

        progressBar = find(R.id.progress)
        Utilities.checkPermission(this)

        mRecyclerView = find(R.id.rvAllApps)
        mLinearLayoutManager = LinearLayoutManager(this)
        mAdapter = AppAdapter(appList, this)

        mRecyclerView.layoutManager = mLinearLayoutManager
        mRecyclerView.adapter = mAdapter

        loadApps()
    }

    private fun loadJSONFromAssets(): String {
        var json: String? = null
        try {
            val inputStream = this.assets.open("permissions_dict.json")
            val size = inputStream.available()
            val buffer = ByteArray(size)
            inputStream.read(buffer)
            inputStream.close()
            json = String(buffer)
        }
        catch (ex: IOException) {
            ex.printStackTrace()
            return "{}"
        }
        return json
    }

    private fun loadInitialDatabaseFromJSON(): String {
        var json: String? = null
        try {
            val inputStream = this.assets.open("initial_database.json")
            val size = inputStream.available()
            val buffer = ByteArray(size)
            inputStream.read(buffer)
            inputStream.close()
            json = String(buffer)
        }
        catch (ex: IOException) {
            ex.printStackTrace()
            return "{}"
        }
        return json
    }

    private fun loadPermissionSignaturesFromJSON(): String {
        var json: String? = null
        try {
            val inputStream = this.assets.open("permission_signature.json")
            val size = inputStream.available()
            val buffer = ByteArray(size)
            inputStream.read(buffer)
            inputStream.close()
            json = String(buffer)
        }
        catch (ex: IOException) {
            ex.printStackTrace()
            return "{}"
        }
        return json
    }

    private fun loadApps() {
        doAsync {
            // Loading database containing whitelisted and blacklisted package names
            val jsonDBObject = JSONObject(loadInitialDatabaseFromJSON())
            val whitelistedBloomFilter =
                BloomFilter.create<String>(Funnels.stringFunnel(Charset.forName("UTF-8")), 7500, 0.001)
            val blacklistedBloomFilter =
                BloomFilter.create<String>(Funnels.stringFunnel(Charset.forName("UTF-8")), 7500, 0.001)

            val whitelisted = jsonDBObject.optJSONArray("whitelist")
            for (i in 0 until whitelisted.length()) {
                val whitePackageName = whitelisted.getString(i)
                whitelistedBloomFilter.put(whitePackageName)
            }
            val blacklisted = jsonDBObject.optJSONArray("blacklist")
            for (i in 0 until blacklisted.length()) {
                val whitePackageName = blacklisted.getString(i)
                blacklistedBloomFilter.put(whitePackageName)
            }

            // Loading permission signatures of malicious apps
            val jsonSignObject = JSONObject(loadPermissionSignaturesFromJSON())
            val malPermissions = jsonSignObject.optJSONArray("signatures")
            val malPermsArray: MutableList<String> = ArrayList()

            logBTP("Num signatures: ${malPermissions.length()}")
            // Iterating through 2D array malPermissions and combining strings to convert it into a 1D array malPermsArray
            for (i in 0 until malPermissions.length()) {
                val aPermissionArray = malPermissions.getJSONArray(i)
                val allPermissions: MutableList<String> = ArrayList()
                for (j in 0 until aPermissionArray.length()) {
                    allPermissions.add(aPermissionArray.getString(j))
                }
                allPermissions.sort()
                var combinedPermissionSignatureStr: String = ""
                for (perm in allPermissions) {
                    combinedPermissionSignatureStr += perm
                }
                malPermsArray.add(combinedPermissionSignatureStr)
            }
            // Sorting so that shortest permission signature strings are searched first on iteration
            malPermsArray.sortWith((Comparator { lhs, rhs ->
                val i1 = lhs.length
                val i2 = rhs.length
                when {
                    i1 < i2 -> -1
                    i1 > i2 -> 1
                    else -> 0
                }
            }))

            // Loading app permission input vector for ML Model 1
            val allPackages = packageManager.getInstalledPackages(PackageManager.GET_PERMISSIONS)
            allPackages.sortWith((Comparator { lhs, rhs ->
                val i1 = packageManager.getApplicationLabel(lhs.applicationInfo).toString()
                val i2 = packageManager.getApplicationLabel(rhs.applicationInfo).toString()
                i1.compareTo(i2)
            }))
            val jsonObject = JSONObject(loadJSONFromAssets())
            allPackages.forEach {
                if (packageManager.getLaunchIntentForPackage(it.packageName) != null) {
                    val permissions = it.requestedPermissions
                    val data = HashMap<String, Float>()
                    val permissionsInput = FloatArray(325) // Current Size of permissions_dict.json (CHECK FILE IN ASSETS)

                    var isInDatabase: Boolean = false
                    var isMalicious: Boolean = false

                    // FIRSTLY CHECK IN BLOOM FILTER
                    val isWhiteListed = whitelistedBloomFilter.mightContain(it.packageName)
                    val isBlackListed = blacklistedBloomFilter.mightContain(it.packageName)
                    if (isBlackListed || isWhiteListed) {
                        logBTP("${it.packageName} is in database!")
                        isInDatabase = true
                        if (isWhiteListed) {
                            isMalicious = false
                        } else if (isBlackListed) {
                            isMalicious = true
                        }
                    } else {
                        // NOW CHECK IF PERMISSION SIGNATURE IS PRESENT
                        // Check if app's permission matches malicious permission signatures
                        if (permissions != null) {
                            val tempSortedPermList: MutableList<String> = ArrayList()
                            for (perm in permissions) {
                                if (perm != null) {
                                    tempSortedPermList.add(perm)
                                }
                            }
                            tempSortedPermList.sort()
                            var combinedPermissions = ""
                            for (perm in tempSortedPermList) {
                                combinedPermissions += perm
                            }
                            for (perm in malPermsArray) {
                                if (perm.equals(combinedPermissions, true)) {
                                    isInDatabase = true
                                    isMalicious = true
                                    break
                                }
                            }
                        }
                    }

                    /* --------------- USING ML MODEL --------------- */

                    if (!isInDatabase && permissions != null) {
                        var iterator: Iterator<String> = jsonObject.keys()
                        while (iterator.hasNext()) {
                            val key = iterator.next()
                            data[key] = 0F
                        }
                        for (per in permissions) {
                            if (per != null) {
                                if (data.containsKey(per)) {
                                    data[per] = 1F
                                }
                            }
                        }
                        iterator = jsonObject.keys()
                        var index = 0

                        while (iterator.hasNext()) {
                            if (index >= 325) {
                                break
                            }
                            val key = iterator.next()
                            permissionsInput[index] = data[key]!!
                            index += 1
                        }
                    }

                    val anApp = AppItem(
                        it.applicationInfo,
                        packageManager.getApplicationLabel(it.applicationInfo).toString(),
                        it.packageName,
                        it.versionName,
                        permissions,
                        permissionsInput,
                        isInDatabase,
                        isMalicious
                    )
                    appList.add(anApp)
                }

            }

            uiThread {
                mAdapter.notifyDataSetChanged()
                progressBar.visibility = View.GONE
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        when (requestCode) {
            Utilities.STORAGE_PERMISSION_CODE -> {
                if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                    Utilities.makeAppDir(this)
                } else {
                    Snackbar.make(
                        find(android.R.id.content),
                        "Permission required to extract apk",
                        Snackbar.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_launch -> {
                try {
                    startActivity(packageManager.getLaunchIntentForPackage(contextItemPackageName))
                } catch (e: Exception) {
                    Snackbar.make(
                        find(android.R.id.content),
                        "Can't open this app",
                        Snackbar.LENGTH_SHORT
                    ).show()
                }
            }
            R.id.action_playstore -> {
                try {
                    startActivity(
                        Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse("market://details?id=$contextItemPackageName")
                        )
                    )
                } catch (e: ActivityNotFoundException) {
                    startActivity(
                        Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse("https://play.google.com/store/apps/details?id=$contextItemPackageName")
                        )
                    )
                }

            }
        }
        return true
    }

    override fun onItemClicked(packageName: String) {
        contextItemPackageName = packageName
    }

}