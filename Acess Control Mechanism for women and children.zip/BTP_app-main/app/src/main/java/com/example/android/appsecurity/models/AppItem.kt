package com.example.android.appsecurity.models

import android.content.pm.ApplicationInfo

// Define what belongs to an item of RecyclerView (used to show list of app)
data class AppItem (
    val appInfo: ApplicationInfo,
    val appName: String,
    val appPackageName: String? = "",
    val version: String? = "",
    val allPermissions: Array<String?>?,
    val permissionsInput: FloatArray,
    val isInDatabase: Boolean = false,
    val isMalicious: Boolean = false,
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as AppItem

        if (!allPermissions.contentEquals(other.allPermissions)) return false

        return true
    }

    override fun hashCode(): Int {
        return allPermissions.contentHashCode()
    }
}