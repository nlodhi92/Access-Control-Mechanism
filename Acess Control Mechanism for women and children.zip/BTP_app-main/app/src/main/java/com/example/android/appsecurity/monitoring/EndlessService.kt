package com.example.android.appsecurity.monitoring

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.media.AudioRecordingConfiguration
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.android.appsecurity.MainActivity
import com.example.android.appsecurity.R
import com.example.android.appsecurity.extras.logBTP
import java.lang.Exception

class EndlessService : Service() {

    private var wakeLock: PowerManager.WakeLock? = null
    private var isServiceStarted = false
    // Notification
    private val NOTIFICATION_CHANNEL_ID = "BTP_APP_SERVICE_CHANNEL"
    private val NOTIFICATION_CHANNEL_NAME = "BTP app service notification channel"
    private val NOTIFICATION_ID = 0
    // Camera Manager
    private var cameraManager: CameraManager? = null
    private var cameraTracker: CameraManager.AvailabilityCallback? = null
    // Audio Manager
    private var audioManager: AudioManager? = null
    private var audioTracker: AudioManager.AudioRecordingCallback? = null

    override fun onBind(intent: Intent?): IBinder? {
        logBTP("Some component wants to bind with the service")
        // We don't provide binding, so return null
        return null
    }

    override fun onCreate() {
        super.onCreate()
        logBTP("Service has been created!")
        createNotificationChannel()
        val notification = createServiceNotification()
        startForeground(1, notification)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        logBTP("onStartCommand executed with startId: $startId")
        if (intent != null) {
            val action = intent.action
            logBTP("Using intent with action $action")
            when (action) {
                Actions.START.name -> startService()
                Actions.STOP.name -> stopService()
                else -> logBTP("Something wrong... No action in intent?")
            }
        } else {
            logBTP("Got null intent.. probably restarted by system")
        }
        // by returning this we make sure the service is restarted if the system kills the service
        return START_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent) {
        val restartServiceIntent = Intent(applicationContext, EndlessService::class.java).also {
            it.setPackage(packageName)
        };
        val restartServicePendingIntent: PendingIntent = PendingIntent.getService(this, 1, restartServiceIntent, PendingIntent.FLAG_ONE_SHOT);
        applicationContext.getSystemService(Context.ALARM_SERVICE);
        val alarmService: AlarmManager = applicationContext.getSystemService(Context.ALARM_SERVICE) as AlarmManager;
        alarmService.set(AlarmManager.ELAPSED_REALTIME, SystemClock.elapsedRealtime() + 1000, restartServicePendingIntent);
    }

    override fun onDestroy() {
        super.onDestroy()
        logBTP("Service has been destroyed!")
        Toast.makeText(this, "Service destroyed", Toast.LENGTH_SHORT).show()
        stopTrackingCamera()
        stopTrackingMicrophone()
    }

    /* ---------------------------- STARTING SERVICE ---------------------------- */
    private fun startService() {
        if (isServiceStarted) return
        setServiceState(this, ServiceState.STARTED)
        isServiceStarted = true
        logBTP("Starting foreground service")
        Toast.makeText(this, "Service Started", Toast.LENGTH_SHORT).show()

        // we need this lock so that our service does not get affected by Doze mode
        wakeLock = (getSystemService(Context.POWER_SERVICE) as PowerManager).run {
            newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "EndlessService::lock").apply {
                acquire()
            }
        }
        // Tracking Camera
        startTrackingCamera()
        // Tracking Microphone
        startTrackMicrophone()
    }

    /* --------------------------------- TRACKERS ------------------------------- */

    private fun startTrackingCamera() {
        logBTP("Alright.. trying to sense camera")
        cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        if (cameraManager != null) {
            cameraTracker = object: CameraManager.AvailabilityCallback() {
                override fun onCameraAvailable(cameraId: String) {
                    super.onCameraAvailable(cameraId)
//                    if (cameraId == "0")
//                        createNotification("Back camera is idle!")
//                    else
//                        createNotification("Front camera is idle!")
                }
                override fun onCameraUnavailable(cameraId: String) {
                    super.onCameraUnavailable(cameraId)
                    if (cameraId == "0")
                        createNotification("Back camera in use!")
                    else
                        createNotification("Front camera in use!")
                }
            }
            cameraManager!!.registerAvailabilityCallback(cameraTracker!!, null)
        } else {
            logBTP("cameraManager is null.. somehow")
        }
    }

    private fun stopTrackingCamera() {
        if (cameraManager != null && cameraTracker != null) {
            cameraManager!!.unregisterAvailabilityCallback(cameraTracker!!)
        }
    }

    private fun startTrackMicrophone() {
        logBTP("Alright.. trying to sense microphone")
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (audioManager != null) {
            audioTracker = object: AudioManager.AudioRecordingCallback() {
                private var isRecording: Boolean = false
                override fun onRecordingConfigChanged(configs: MutableList<AudioRecordingConfiguration>?) {
                    super.onRecordingConfigChanged(configs)
                    isRecording = !isRecording
                    if (isRecording) {
                        createNotification("Recording started!")
                    } else {
                        createNotification("Recording stopped!")
                    }
                }
            }
            audioManager!!.registerAudioRecordingCallback(audioTracker!!, null)
        } else {
            logBTP("audioManager is null.. somehow")
        }
    }

    private fun stopTrackingMicrophone() {
        if (audioManager != null && audioTracker != null) {
            audioManager!!.unregisterAudioRecordingCallback(audioTracker!!)
        }
    }

    /* ---------------------------- STOPPING SERVICE ---------------------------- */
    private fun stopService() {
        if (!isServiceStarted) return
        logBTP("Stopping foreground service")
        Toast.makeText(this, "Service Stopped", Toast.LENGTH_SHORT).show()
        try {
            wakeLock?.let {
                if (it.isHeld) {
                    it.release()
                }
            }
            stopForeground(true)
            stopSelf()
        } catch (e: Exception) {
            logBTP("Error while stopping service: ${e.message}")
        }
        isServiceStarted = false
        setServiceState(this, ServiceState.STOPPED)
    }

    /* ---------------------------- CREATING NOTIFICATION ---------------------------- */

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                NOTIFICATION_CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).let {
                it.description = "Service channel"
                it.enableLights(true)
                it.lightColor = Color.RED
                it.enableVibration(true)
                it.vibrationPattern = longArrayOf(100, 200, 300, 400, 500, 400, 300, 200, 400)
                it
            }
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun createNotification(msg: String) {
        // Tapping on notification will open our app
        val pendingIntent: PendingIntent = Intent(this, MainActivity::class.java).let { notificationIntent ->
            PendingIntent.getActivity(this, 0, notificationIntent, 0)
        }

        // Create the notification that you want to post on your notification channel
        val notification = NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setContentTitle("App Security")
            .setContentText(msg)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .build()

        // Create a notification manager
        val notificationManager = NotificationManagerCompat.from(this)

        notificationManager.notify(NOTIFICATION_ID, notification)
    }

    private fun createServiceNotification(): Notification {
        // Tapping on notification will open our app
        val pendingIntent: PendingIntent = Intent(this, MainActivity::class.java).let { notificationIntent ->
            PendingIntent.getActivity(this, 0, notificationIntent, 0)
        }

        //val builder = NotificationCompat.Builder(this, notificationChannelId)
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(
            this,
            NOTIFICATION_CHANNEL_ID
        ) else Notification.Builder (this)

        return builder
            .setContentTitle("App Security")
            .setContentText("Monitoring your device")
            .setContentIntent(pendingIntent)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setTicker("Ticker text")
            .setPriority(Notification.PRIORITY_HIGH) // for under api 26 compatibility
            .build()
    }

}